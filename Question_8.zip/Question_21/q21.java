package Question_21;

import javax.swing.*;

public class q21 extends JFrame {

    private JTextField textField;

    public q21() {
        super("Simple Number Display");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        textField = new JTextField();
        textField.setBounds(50, 50, 200, 50);
        add(textField);

        new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                final int num = i;
                SwingUtilities.invokeLater(() -> textField.setText(String.valueOf(num)));
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new q21().setVisible(true);
        });
    }
}
