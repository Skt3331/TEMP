package Question_12;

import java.sql.*;

public class Q6 {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost/postgres";
        String user = "postgres";
        String password = "root";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the PostgreSQL server successfully.");

          
            String updateSQL = "UPDATE Course SET number_of_students = ? WHERE name = ?";
            PreparedStatement pstmt = conn.prepareStatement(updateSQL);

            pstmt.setInt(1, 1000);
            pstmt.setString(2, "BCA Science");

            int rowsAffected = pstmt.executeUpdate();
            System.out.println("Updated " + rowsAffected + " row(s) successfully.");

       
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
