package Question_28;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseOperations {
    private static final String URL = "jdbc:postgresql://localhost/postgres";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        createTables();    
        addColumn("table1", "newColumn VARCHAR(255)");
        dropTable("table5"); 
    }

    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

   
    private static void createTables() {
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
           
            stmt.execute("CREATE TABLE IF NOT EXISTS table1 (id SERIAL PRIMARY KEY, name VARCHAR(255))");
            stmt.execute("CREATE TABLE IF NOT EXISTS table2 (id SERIAL PRIMARY KEY, description TEXT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS table3 (id SERIAL PRIMARY KEY, price DECIMAL)");
            stmt.execute("CREATE TABLE IF NOT EXISTS table4 (id SERIAL PRIMARY KEY, quantity INT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS table5 (id SERIAL PRIMARY KEY, status BOOLEAN)");

            System.out.println("Tables created successfully.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    
    private static void addColumn(String tableName, String columnDefinition) {
        String SQL = String.format("ALTER TABLE %s ADD COLUMN %s", tableName, columnDefinition);
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(SQL);
            System.out.println("Column added successfully to " + tableName);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    private static void dropTable(String tableName) {
        String SQL = "DROP TABLE IF EXISTS " + tableName;
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(SQL);
            System.out.println(tableName + " dropped successfully.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
