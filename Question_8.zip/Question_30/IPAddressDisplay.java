package Question_30;

import java.net.*;

public class IPAddressDisplay {
    public static void main(String[] args) {
        try {
          
            InetAddress localhost = InetAddress.getLocalHost();
   
            System.out.println("Host Name: " + localhost.getHostName());
            System.out.println("IP Address: " + localhost.getHostAddress());
        } catch (UnknownHostException uhe) {
            System.err.println("Unable to determine the host IP address.");
            uhe.printStackTrace();
        }
    }
}
