package Question_10;
import javax.swing.*;
import java.awt.*;

public class q10 extends JFrame implements Runnable {
    private final JLabel redLight;
    private final JLabel yellowLight;
    private final JLabel greenLight;

    public q10() {
        super("Traffic Signal Simulator");
        setLayout(new GridLayout(3, 1));
        setSize(200, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        redLight = createLight(Color.RED);
        yellowLight = createLight(Color.YELLOW);
        greenLight = createLight(Color.GREEN);

        add(redLight);
        add(yellowLight);
        add(greenLight);

        setVisible(true);
    }

    private JLabel createLight(Color color) {
        JLabel light = new JLabel();
        light.setOpaque(true);
        light.setBackground(Color.DARK_GRAY);
        light.setPreferredSize(new Dimension(180, 180));
        light.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        return light;
    }

    public void run() {
        try {
            while (true) {
                turnOnLight(greenLight, Color.GREEN);
                Thread.sleep(5000); // green for 5 seconds

                turnOnLight(yellowLight, Color.YELLOW);
                Thread.sleep(2000); // yellow for 2 seconds

                turnOnLight(redLight, Color.RED);
                Thread.sleep(5000); // red for 5 seconds
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread interrupted");
        }
    }

    private void turnOnLight(JLabel light, Color color) {
        // Turn all lights off
        redLight.setBackground(Color.DARK_GRAY);
        yellowLight.setBackground(Color.DARK_GRAY);
        greenLight.setBackground(Color.DARK_GRAY);

        // Turn the specified light on
        light.setBackground(color);
    }

    public static void main(String[] args) {
        q10 trafficSignal = new q10();
        Thread thread = new Thread(trafficSignal);
        thread.start();
    }
}
