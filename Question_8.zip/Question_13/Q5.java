package Question_13;

import java.sql.*;

public class Q5 {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost/postgres";
        String user = "postgres";
        String password = "root";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the PostgreSQL server successfully.");

           
            String query1986 = "SELECT * FROM Person1 WHERE birth_year = 1986";
            PreparedStatement pstmt1986 = conn.prepareStatement(query1986);
            ResultSet rs1986 = pstmt1986.executeQuery();
            System.out.println("Persons born in 1986:");
            while (rs1986.next()) {
                System.out.println("PID: " + rs1986.getInt("PID") + ", Name: " + rs1986.getString("name") +
                                   ", Gender: " + rs1986.getString("gender").trim() + ", Birth Year: " + rs1986.getInt("birth_year"));
            }

          
            String queryFemales = "SELECT * FROM Person1 WHERE gender = 'F' AND birth_year BETWEEN 2000 AND 2005";
            PreparedStatement pstmtFemales = conn.prepareStatement(queryFemales);
            ResultSet rsFemales = pstmtFemales.executeQuery();
            System.out.println("Females born between 2000 and 2005:");
            while (rsFemales.next()) {
                System.out.println("PID: " + rsFemales.getInt("PID") + ", Name: " + rsFemales.getString("name") +
                                   ", Gender: " + rsFemales.getString("gender").trim() + ", Birth Year: " + rsFemales.getInt("birth_year"));
            }

                        rs1986.close();
            pstmt1986.close();
            rsFemales.close();
            pstmtFemales.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
