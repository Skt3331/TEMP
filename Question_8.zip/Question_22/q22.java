package Question_22;

public class q22 extends Thread {

    
    public void run() {
        try {
           
            for (char c = 'Z'; c >= 'A'; c--) {
                System.out.println(c);
              
                Thread.sleep(5000);
            }
        } catch (InterruptedException e) {
            System.out.println("Thread was interrupted!");
        }
    }

    public static void main(String[] args) {
        q22 thread = new q22();
        thread.start();
    }
}
