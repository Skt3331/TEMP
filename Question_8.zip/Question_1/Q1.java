package Question_1;



import java.sql.*;
import java.io.*;

public class Q1
{
  public static void main(String args[])
  {
    try
    {
	  Class.forName("org.postgresql.Driver");
	  

       Connection conn1 = DriverManager.getConnection("jdbc:postgresql://localhost/postgres","postgres", "root");


      
         
           System.out.println("Connected to the PostgreSQL server successfully.");
           Statement stmt1 = conn1.createStatement();
           ResultSet rs1 = stmt1.executeQuery("SELECT * FROM Person");
           System.out.println("PID | Name     | Gender | Birth Year");
           while (rs1.next()) {
               int pid = rs1.getInt("PID");
               String name = rs1.getString("name");
               String gender = rs1.getString("gender").trim(); 
               int birthYear = rs1.getInt("birth_year");
               System.out.printf("%3d | %-8s | %-6s | %d%n", pid, name, gender, birthYear);
           }
           rs1.close();
           stmt1.close();
           conn1.close();
       } catch (Exception e) {
           e.printStackTrace();
       }

  }
}

