/**
 * 
 */
/**
 * 
 */
module jss {
	requires java.sql;
	requires java.desktop;
}