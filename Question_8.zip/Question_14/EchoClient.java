package Question_14;
import java.io.*;
import java.net.*;

public class EchoClient {
    private static final String host = "localhost";
    private static final int port = 6868;

    public static void main(String[] args) {
        try (Socket socket = new Socket(host, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {
             
            String userInput;
            System.out.println("Type 'END' to exit.");
            
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput);
                if ("END".equalsIgnoreCase(userInput)) {
                    break;
                }
                System.out.println("Server reply: " + in.readLine());
            }
            
        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O error: " + ex.getMessage());
        }
    }
}
