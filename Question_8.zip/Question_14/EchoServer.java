
package Question_14;
import java.io.*;
import java.net.*;

public class EchoServer {
    public static void main(String[] args) {
        int port = 6868;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);
            
            Socket socket = serverSocket.accept();
            System.out.println("Client connected");
            
            try (BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter output = new PrintWriter(socket.getOutputStream(), true)) {
                 
                String text;
                
                while ((text = input.readLine()) != null) {
                    if ("END".equals(text)) {
                        System.out.println("Received END, closing connection.");
                        break;
                    }
                    output.println("Echo: " + text);
                }
            } catch (IOException e) {
                System.out.println("Error handling client: " + e.getMessage());
            } finally {
                socket.close();
                System.out.println("Connection with client closed");
            }
        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
