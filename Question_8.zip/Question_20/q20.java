package Question_20;

import java.sql.*;

public class q20 {

    public static void main(String[] args) {

        String url = "jdbc:postgresql://localhost:5432/postgres";
        String username = "postgres";
        String password = "root";
        String tableName = "Person";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {
           
            try (var ab = statement.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
                if (ab.next()) { 
                    long count = ab.getLong(1);
                    System.out.println("Number of records in " + tableName + ": " + count);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
