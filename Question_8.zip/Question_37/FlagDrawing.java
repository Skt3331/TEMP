package Question_37;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class FlagDrawing extends JFrame {
    public FlagDrawing() {
        super("Indian National Flag");
        setSize(360, 240);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(new FlagPanel());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FlagDrawing().setVisible(true));
    }

    private static class FlagPanel extends JPanel {
        
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            int width = getWidth();
            int stripeHeight = getHeight() / 3;

    
            g2d.setColor(new Color(255, 153, 51)); // Saffron color
            g2d.fillRect(0, 0, width, stripeHeight);

            g2d.setColor(Color.WHITE);
            g2d.fillRect(0, stripeHeight, width, stripeHeight);

            g2d.setColor(new Color(19, 136, 8)); // India green color
            g2d.fillRect(0, 2 * stripeHeight, width, stripeHeight);

          
            g2d.setColor(new Color(0, 0, 128)); // Navy blue
            double circleRadius = stripeHeight / 2;
            double circleX = (width / 2) - circleRadius;
            double circleY = (getHeight() / 2) - circleRadius;
            Ellipse2D.Double circle = new Ellipse2D.Double(circleX, circleY, 2 * circleRadius, 2 * circleRadius);
            g2d.fill(circle);

            
            double angleStep = 360.0 / 24;
            for (int i = 0; i < 24; i++) {
                g2d.rotate(Math.toRadians(angleStep), width / 2, getHeight() / 2);
                g2d.drawLine(width / 2, getHeight() / 2 - (int) circleRadius,
                             width / 2, getHeight() / 2 - (int) (circleRadius * 0.6));
            }
        }
    }
}
