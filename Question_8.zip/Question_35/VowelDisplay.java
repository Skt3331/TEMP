package Question_35;

public class VowelDisplay {
    public static void main(String[] args) {
        String input = "Saurav";
        System.out.println("Input string: " + input);

        input = input.toLowerCase();

        char[] vowels = {'a', 'e', 'i', 'o', 'u'};

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            for (char v : vowels) {
                if (c == v) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        System.out.println("Sleep interrupted: " + e.getMessage());
                    }
                    System.out.println("Vowel found: " + c);
                    break; 
                }
            }
        }
    }
}
