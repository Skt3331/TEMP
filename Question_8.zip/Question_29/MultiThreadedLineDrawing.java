package Question_29;

import javax.swing.*;
import java.awt.*;

public class MultiThreadedLineDrawing extends JFrame {
    private static final int LINE_COUNT = 5;

    public MultiThreadedLineDrawing() {
        super("Multithreaded Line Drawing");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(new LinePanel());
    }


    private static class LinePanel extends JPanel {
     
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int width = getWidth();
            int height = getHeight();
            int spacing = width / (LINE_COUNT + 1);

            for (int i = 1; i <= LINE_COUNT; i++) {
                int x = spacing * i;
               
                Thread drawer = new Thread(() -> drawLine(g, x, 0, x, height));
                drawer.start();
                try {
                    drawer.join();  // Wait for the thread to finish drawing
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("Thread interrupted: " + e.getMessage());
                }
            }
        }

        private void drawLine(Graphics g, int x1, int y1, int x2, int y2) {
            g.drawLine(x1, y1, x2, y2);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MultiThreadedLineDrawing().setVisible(true));
    }
}
