package Question_41;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ImageBlinker extends JFrame {
    private ImageIcon imageIcon;
    private JLabel imageLabel;
    private Timer timer;
    private boolean isVisible = true;

    public ImageBlinker() {
        
        setSize(300, 300);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

     
        imageIcon = new ImageIcon("path/to/your/image.jpg");
        imageLabel = new JLabel(imageIcon);
        add(imageLabel, BorderLayout.CENTER);

       
        timer = new Timer(500, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                toggleImageVisibility();
            }
        });
        timer.start();
    }

    private void toggleImageVisibility() {
        isVisible = !isVisible; // Toggle visibility state
        imageLabel.setVisible(isVisible); // Apply visibility
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ImageBlinker().setVisible(true);
            }
        });
    }
}
