import java.io.*;
import java.net.*;

public class ChatServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Server started. Waiting for clients to connect...");
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected.");

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            String userInput;
            String clientInput;

            while (true) {
                // Reading client's message
                if ((clientInput = in.readLine()) != null) {
                    System.out.println("Client: " + clientInput);
                }

                // Reading user input
                System.out.print("You: ");
                userInput = consoleInput.readLine();
                out.println(userInput);

                if (userInput.equalsIgnoreCase("bye")) {
                    break;
                }
            }

            // Closing resources
            in.close();
            out.close();
            consoleInput.close();
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

