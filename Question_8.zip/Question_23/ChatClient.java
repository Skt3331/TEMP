import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            String userInput;
            String serverInput;

            while (true) {
                // Reading server's message
                if ((serverInput = in.readLine()) != null) {
                    System.out.println("Server: " + serverInput);
                }

                // Reading user input
                System.out.print("You: ");
                userInput = consoleInput.readLine();
                out.println(userInput);

                if (userInput.equalsIgnoreCase("bye")) {
                    break;
                }
            }

            // Closing resources
            in.close();
            out.close();
            consoleInput.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

