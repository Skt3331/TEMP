package Question_8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/postgres"; 
        String user = "postgres"; 
        String password = "root"; 
        Scanner scanner = new Scanner(System.in);

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO Employee (ID, Name, Salary) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            System.out.println("Enter employee details:");
            while (true) {
                System.out.print("Enter ID (or type 'exit' to quit): ");
                String input = scanner.nextLine();
                if ("exit".equalsIgnoreCase(input)) break;

                int id = Integer.parseInt(input);

                System.out.print("Enter Name: ");
                String name = scanner.nextLine();

                System.out.print("Enter Salary: ");
                double salary = Double.parseDouble(scanner.nextLine());

                preparedStatement.setInt(1, id);
                preparedStatement.setString(2, name);
                preparedStatement.setDouble(3, salary);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Employee details inserted successfully.");
                } else {
                    System.out.println("Failed to insert employee details.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
