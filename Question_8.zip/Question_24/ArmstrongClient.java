package Question_24;
import java.io.*;
import java.net.*;

public class ArmstrongClient {
    public static void main(String[] args) throws IOException {
        String serverAddress = "127.0.0.1";  // Localhost IP
        int port = 6789;
        Socket socket = new Socket(serverAddress, port);

        try (BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            
            System.out.println("Enter a number: ");
            String userInput = stdIn.readLine();
            out.println(userInput);
            String response = in.readLine();
            System.out.println("Server says: " + response);
        } finally {
            socket.close();
        }
    }
}
