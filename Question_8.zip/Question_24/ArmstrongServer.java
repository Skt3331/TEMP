package Question_24;

import java.io.*;
import java.net.*;

public class ArmstrongServer {
    public static void main(String[] args) throws IOException {
        int port = 6789;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Server is listening on port " + port);

        try {
            while (true) {
                Socket socket = serverSocket.accept();
                try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                    
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        int num = Integer.parseInt(inputLine);
                        boolean isArmstrong = isArmstrong(num);
                        out.println(num + " is " + (isArmstrong ? "" : "not ") + "an Armstrong number.");
                    }
                } catch (IOException e) {
                    System.out.println("Exception caught when trying to listen on port " + port + " or listening for a connection");
                    System.out.println(e.getMessage());
                }
            }
        } finally {
            serverSocket.close();
        }
    }

    private static boolean isArmstrong(int number) {
        int result = 0;
        int originalNumber = number;
        int digits = String.valueOf(number).length();
        while (number != 0) {
            int remainder = number % 10;
            result += Math.pow(remainder, digits);
            number /= 10;
        }
        return result == originalNumber;
    }
}
