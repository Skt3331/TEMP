package Question_3;


import java.io.*;
import java.net.*;

public class FileServer {
    public static void main(String[] args) {

        try {
            ServerSocket serverSoc = new ServerSocket(8066);
            System.out.println("Server is running on port " + 8070);

            while (true) {
               
                Socket clientSoc = serverSoc.accept();
                System.out.println("Client connected.");

               
                DataInputStream input = new DataInputStream(clientSoc.getInputStream());
                DataOutputStream output = new DataOutputStream(clientSoc.getOutputStream());

                
                String fileName = input.readUTF();
                System.out.println("Received request for file: " + fileName);

            
                File file = new File(fileName);
                if (file.exists() && file.isFile()) 
                {
                    output.writeBoolean(true); 
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = br.readLine()) != null) {
                        output.writeBytes(line + "\n");
                    }
                    br.close();
                } 
                else {
                    output.writeBoolean(false); // Indicate that the file does not exist
                }

                clientSoc.close();
                System.out.println("Client disconnected.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

