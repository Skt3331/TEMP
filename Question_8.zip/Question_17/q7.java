package Question_17;

public class q7 {
    public static void main(String[] args) {
        Thread countdown = new Thread(() -> {
            try {
                for (int i = 100; i >= 1; i--) {
                    Thread.currentThread().setName("Countdown: " + i);
                    System.out.println("Current count: " + i + ", Thread Name: " + Thread.currentThread().getName());
                    Thread.sleep(6000); 
                }
            } catch (InterruptedException e) {
                System.out.println("Thread was interrupted.");
            }
        });

        countdown.start();
    }
}
