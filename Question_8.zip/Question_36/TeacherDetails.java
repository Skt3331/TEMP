package Question_36;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TeacherDetails {
    private static final String URL = "jdbc:postgresql://localhost/postgres";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Teacher ID: ");
        int tid = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Teacher Name: ");
        String tname = scanner.nextLine();
        System.out.print("Enter Salary: ");
        double salary = scanner.nextDouble();
        insertTeacher(tid, tname, salary);
        scanner.close();
    }

    private static void insertTeacher(int tid, String tname, double salary) {
        String sql = "INSERT INTO Teachers (TID, TName, Salary) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, tid);
            pstmt.setString(2, tname);
            pstmt.setDouble(3, salary);

            // Execute the update
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Data inserted successfully.");
            } else {
                System.out.println("A problem occurred, no data was inserted.");
            }
        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
    }
}
