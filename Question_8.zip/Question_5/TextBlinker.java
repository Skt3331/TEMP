package Question_5;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TextBlinker implements Runnable {
    private JFrame frame;
    private JLabel label;
    private boolean running = true;

    public TextBlinker() {
        
        frame = new JFrame("Text Blinker");
        frame.setSize(300, 200);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
           
            public void windowClosing(WindowEvent e) {
                running = false;
                frame.dispose();
            }
        });

        label = new JLabel("Blinking Text");
        label.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(label);

        frame.setLocationRelativeTo(null); // Center on screen
        frame.setVisible(true);
    }

   
    public void run() {

        while (running) {
            try {
                SwingUtilities.invokeLater(() -> label.setVisible(!label.isVisible())); // Toggle visibility
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Thread was interrupted, Failed to complete operation");
            }
        }
    }

    public static void main(String[] args) {
        TextBlinker blinker = new TextBlinker();
        Thread thread = new Thread(blinker);
        thread.start();
    }
}
