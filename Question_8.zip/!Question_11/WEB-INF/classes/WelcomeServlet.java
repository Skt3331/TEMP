

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class WelcomeServlet extends HttpServlet {


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       
        response.setContentType("text/html");
        
     
        PrintWriter out = response.getWriter();
        
   
        String clientIP = request.getRemoteAddr();
        
       
        Cookie[] cookies = request.getCookies();
        boolean isNewVisitor = true;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visited") && cookie.getValue().equals(clientIP)) {
                    isNewVisitor = false;
                    break;
                }
            }
        }

        
        if (isNewVisitor) {
            out.println("<html><body>");
            out.println("<h1>Welcome " + clientIP + "</h1>");
            out.println("</body></html>");
            
            Cookie newCookie = new Cookie("visited", clientIP);
            newCookie.setMaxAge(24 * 60 * 60); 
            response.addCookie(newCookie);
        } else {
            out.println("<html><body>");
            out.println("<h1>Welcome back " + clientIP + "</h1>");
            out.println("</body></html>");
        }

        out.close();
    }
}
