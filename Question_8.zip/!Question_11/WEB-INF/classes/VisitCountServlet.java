import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class VisitCountServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Cookie[] cookies = request.getCookies();
        Cookie visitCookie = null;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visitCount")) {
                    visitCookie = cookie;
                    break;
                }
            }
        }

        if (visitCookie == null) {
            out.println("<html><body>");
            out.println("<h1>Welcome to the site!</h1>");
            out.println("<p>This is your first visit.</p>");
            out.println("</body></html>");

            
            visitCookie = new Cookie("visitCount", "1");
            visitCookie.setMaxAge(60 * 60 * 24 * 365); // Store cookie for a year
        } else {
            int visitCount = Integer.parseInt(visitCookie.getValue());
            visitCount++;
            out.println("<html><body>");
            out.println("<h1>Welcome back!</h1>");
            out.println("<p>You have visited this site " + visitCount + " times.</p>");
            out.println("</body></html>");

           
            visitCookie.setValue(Integer.toString(visitCount));
        }

        response.addCookie(visitCookie);
    }
}
