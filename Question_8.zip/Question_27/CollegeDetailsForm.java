package Question_27;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CollegeDetailsForm extends JFrame {
  
    private JTextField cidField = new JTextField(10);
    private JTextField cnameField = new JTextField(20);
    private JTextField addressField = new JTextField(20);
    private JButton submitButton = new JButton("Show Details");

  
    public CollegeDetailsForm() {
        super("Enter College Details");
        setLayout(new FlowLayout());

        add(new JLabel("College ID:"));
        add(cidField);
        add(new JLabel("College Name:"));
        add(cnameField);
        add(new JLabel("Address:"));
        add(addressField);
        add(submitButton);


        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayDetails();
            }
        });

        setSize(250, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 
    }

    private void displayDetails() {
       
        String details = "<html>College ID: " + cidField.getText() + "<br>" +
                         "College Name: " + cnameField.getText() + "<br>" +
                         "Address: " + addressField.getText() + "</html>";


        JFrame detailsFrame = new JFrame("College Details");
        detailsFrame.setLayout(new FlowLayout());
        detailsFrame.add(new JLabel(details));
        detailsFrame.setSize(300, 120);
        detailsFrame.setVisible(true);
        detailsFrame.setLocationRelativeTo(null);  
    }

    public static void main(String[] args) {
        new CollegeDetailsForm().setVisible(true);
    }
}
