import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CollegeDetailsForm extends JFrame implements ActionListener {
    private JTextField cidField, cnameField, addressField;
    private JButton submitButton;
    private Connection connection;

    public CollegeDetailsForm() {
        setTitle("College Details Form");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2));

        JLabel cidLabel = new JLabel("CID:");
        cidField = new JTextField();
        add(cidLabel);
        add(cidField);

        JLabel cnameLabel = new JLabel("CName:");
        cnameField = new JTextField();
        add(cnameLabel);
        add(cnameField);

        JLabel addressLabel = new JLabel("Address:");
        addressField = new JTextField();
        add(addressLabel);
        add(addressField);

        submitButton = new JButton("Submit");
        submitButton.addActionListener(this);
        add(submitButton);

        setVisible(true);

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            String cid = cidField.getText();
            String cname = cnameField.getText();
            String address = addressField.getText();

            try {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO colleges (CID, CName, Address) VALUES (?, ?, ?)");
                preparedStatement.setString(1, cid);
                preparedStatement.setString(2, cname);
                preparedStatement.setString(3, address);
                preparedStatement.executeUpdate();
                preparedStatement.close();

                displayCollegeDetails(cid, cname, address);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void displayCollegeDetails(String cid, String cname, String address) {
        JFrame displayFrame = new JFrame("College Details");
        displayFrame.setSize(300, 150);
        displayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        displayFrame.setLocationRelativeTo(null);
        displayFrame.setLayout(new GridLayout(3, 1));

        JLabel cidLabel = new JLabel("CID: " + cid);
        JLabel cnameLabel = new JLabel("CName: " + cname);
        JLabel addressLabel = new JLabel("Address: " + address);

        displayFrame.add(cidLabel);
        displayFrame.add(cnameLabel);
        displayFrame.add(addressLabel);

        displayFrame.setVisible(true);
    }

    public static void main(String[] args) {
        new CollegeDetailsForm();
    }
}

